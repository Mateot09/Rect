import React, {useState} from "react";

export const InsertViewModel = () => {
    const [values, setvalues] = useState({
        nombre: '',
        apellido: '',
        email: '',
        carrera: '',
        año: '',
    })  

    const onChange = (propierty: string, value: any) => {
        setvalues({ ...values, [propierty]:value})
    }

    const insertdb = () => (
        console.log(JSON.stringify(values))
    )

    return {
        ...values, onChange, insertdb
    }
}

export default InsertViewModel   