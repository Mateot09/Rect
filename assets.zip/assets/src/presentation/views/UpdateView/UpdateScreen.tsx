import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { AppColors } from '../../theme/AppTheme';
import { PrimaryBtn, SecondaryBtn } from '../../../components/Botones';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { Input } from '../../../components/Input';
import { View } from 'react-native';
import useViewModel from './ViewModel';
import { StyleSheet } from 'react-native';
import { Image } from 'react-native';

export const UpdateScreen = () => {
    const {id, nombre, apellido, email, carrera, año, onChange, updatedb} = useViewModel();
    return(
        <View style={styles.Container} >
            <StatusBar style='auto' />
            <Image 
                style={styles.BackgroundStyle}
                source={require("../../../../images/school-work-851328_1920.jpg")}
                />
            <View style={styles.FormContainer}>
                <Input 
                    label='Id'
                    placeholder='Escriba el id del estudiante'
                    value={id}
                    propierty='id'
                    keyboard='default'
                    entry=  {false}
                    onChangeText= {onChange}
                />
                <Input 
                    label='Nombre'
                    placeholder='Escriba el nombre del estudiante'
                    value={nombre}
                    propierty='nombre'
                    keyboard='default'
                    entry=  {false}
                    onChangeText= {onChange}
                />
                <Input 
                    label='Apellido'
                    placeholder='Escriba el apellido del estudiante'
                    value={apellido}
                    propierty='apellido'
                    keyboard='default'
                    entry=  {false}
                    onChangeText= {onChange}
                />
                <Input 
                    label='Email'
                    placeholder='Escriba el email del estudiante'
                    value={email}
                    propierty='email'
                    keyboard='default'
                    entry=  {false}
                    onChangeText= {onChange}
                />
                <Input 
                    label='Carrera'
                    placeholder='Escriba la carrera del estudiante'
                    value={carrera}
                    propierty='carrera'
                    keyboard='default'
                    entry=  {false}
                    onChangeText= {onChange}
                />
                <Input 
                    label='Año'
                    placeholder='Escriba el año del estudiante'
                    value={año}
                    propierty='año'
                    keyboard='default'
                    entry=  {false}
                    onChangeText= {onChange}
                />
                <PrimaryBtn
                    text='Actualizar'
                    onPress={()=> updatedb()}
                ></PrimaryBtn>
                <SecondaryBtn 
                    text='Cancelar'
                    onPress={()=> updatedb()}
                ></SecondaryBtn>
            </View>
        </View>
    )
}
const styles = StyleSheet.create({
    FormContainer:{
        left: '50%',
        marginLeft: -200,
        width:  400,
        backgroundColor: 'white',
        padding: 40,
        bottom: 0,
        position: 'absolute',
    },
    Container:{
        flex: 1,
        backgroundColor: 'white',
        justifyContent: 'center',
        
    },
    BackgroundStyle:{
        width: '100%',
        height: '100%',
        opacity: 0.7,
    }
})