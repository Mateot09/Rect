import React from  "react";
import { useNavigation } from "@react-navigation/native";
import { StackNavigationProp } from "@react-navigation/stack";
import { RootStackParamList } from "../../../../../App";
import { StyleSheet, Text, View } from "react-native";
import { PrimaryBtn } from "../../../components/Botones";


export const HomeScreen = () => {
    const Goto = useNavigation<StackNavigationProp<RootStackParamList>>();
    return (
        <View style={styles.MenuStyle}>
            <Text style={styles.TitStyle}>Inicio</Text>
            <View>
                <PrimaryBtn
                    text="Estudiantes"
                    onPress={() => Goto.navigate("ListScreen")}
                />
                <PrimaryBtn
                    text="Nuevo Estudiante"
                    onPress={() => Goto.navigate("InsertScreen")}
                />
                <PrimaryBtn
                    text="Editar Estudiantes"
                    onPress={() => Goto.navigate("UpdateScreen")}
                />
            </View>
        </View>
    )
}
const styles = StyleSheet.create({
    MenuStyle: {
        top: 0,
        bottom: 0,
        backgroundColor: 'powderblue',
        width: 200,
        position: 'absolute',
        paddingTop: 50
    },
    TitStyle:{
        fontSize: 20,
        textTransform: 'capitalize',
        fontWeight: '500',
        textAlign: 'center'
    }
})


