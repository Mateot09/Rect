import React from "react";
import { StatusBar } from "expo-status-bar";
import { AppColors } from "../../theme/AppTheme";
import { PrimaryBtn, SecondaryBtn } from "../../../components/Botones";
import { FlatList, SafeAreaView, StyleSheet, Text } from "react-native";
import { View } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { StackNavigationProp } from "@react-navigation/stack";
import { RootStackParamList } from "../../../../../App";
const data = [
    {
        id: '1',
        nombre: 'Juan',
        apellido: 'Lopez',
    },
    {
        id: '2',
        nombre: 'Luis',
        apellido: 'Perez',
    },
    {
        id: '3',
        nombre: 'Mateo',
        apellido: 'Torres',
    },
    {
        id: '4',
        nombre: 'Fernando',
        apellido: 'Aviles',
    },
];

type ItemProps = {nombre: string, apellido: string,};
const ActionBtn= () => {alert('Click')}
const Item = ({nombre, apellido}: ItemProps) => (
    <View style={styles.ItemStyle}>
        
        <View style={styles.DataStyle}>
            <Text style={{marginEnd: 3}}>{nombre}</Text>
            <Text style={styles.TextStyle}>{apellido}</Text>
        </View>
        <View style={styles.ButtomContainer}>
            <PrimaryBtn text="Actualizar" onPress={ActionBtn}/>
            <SecondaryBtn text="Eliminar" onPress={ActionBtn}/>
        </View>
    </View>
);
export const ListScreen = () => {
    const Navegacion = useNavigation<StackNavigationProp<RootStackParamList>>();
    return (
        <SafeAreaView style={styles.StyleConter}>
            <FlatList 
                data={data}
                renderItem={({item}) => <Item nombre={item.nombre} apellido={item.apellido}/>}  
                keyExtractor={item => item.id}
            />

        </SafeAreaView>

    );
};

const styles = StyleSheet.create({
    StyleConter:{
        flex: 1,
        marginTop: 10
    },
    ItemStyle:{
        paddingVertical: 5,
        paddingHorizontal: 10,
        backgroundColor: 'powderblue',
        flexDirection: 'row',
        width: '100%',
    },
    TextStyle:{
        color: 'black',
    },
    DataStyle:{
        flexDirection: 'row',
        flex: 1,
        position: 'relative',   
    },
    ButtomContainer:{
        flexDirection: 'row',
        position: 'relative',
        marginEnd: 130,
        paddingEnd: 20,
    }
})