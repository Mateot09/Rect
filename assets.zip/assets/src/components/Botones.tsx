import React from 'react';
import {TouchableOpacity, StyleSheet, Text} from 'react-native';
import { AppColors } from '../presentation/theme/AppTheme';

interface Props {
    text:       string,
    onPress: () => void
}

export const PrimaryBtn = ({text, onPress}:Props) => {
    return (
        <TouchableOpacity 
            style={styles.PrimaryBtn}
            onPress={() => onPress()}
        >
            <Text 
                style={styles.StyleText}
            >
                {text}
            </Text>
        </TouchableOpacity>
    )
}

export const SecondaryBtn = ({text, onPress}:Props) => {
    return (
        <TouchableOpacity 
            style={styles.SecondaryBtn}
            onPress={() => onPress()}
        >
            <text 
                style={styles.StyleText}
            >
                {text}
            </text>
        </TouchableOpacity>
    )
}

const styles = StyleSheet.create({
    PrimaryBtn:{
        width:  '100%',
        backgroundColor: AppColors.primary,
        padding: 5,
        marginVertical: 10,
    },
    SecondaryBtn:{
        width:  '100%',
        backgroundColor: AppColors.secondary,
        padding: 5,
        marginVertical: 10,
    },
    StyleText:{
        color:  'white',
        textAlign:  'center',
    }
    
})