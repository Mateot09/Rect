import React from "react";
import { AppColors } from "../presentation/theme/AppTheme";
import { KeyboardType, StyleSheet, Text, TextInput, View } from "react-native";

interface Props {
    label:  string,
    placeholder:  string,
    value:  string,
    propierty:  string,
    keyboard:  KeyboardType,
    entry: boolean,
    onChangeText: (propiedad: string, value: any) => void
}

export const Input = ({label, placeholder, value, propierty, keyboard, entry, onChangeText}:Props) => {
    return (
        <View 
            style={styles.ConterStyle}
        >
            <Text >
                {label}
            </Text>
        <TextInput
        style = {styles.CampStyle}
        placeholder = {placeholder}
        value = {value}
        secureTextEntry = {entry}
        keyboardType = {keyboard}
        onChangeText = {(text) => onChangeText(propierty, text)}
        >
        </TextInput>
        </View>
    )
}

const styles = StyleSheet.create({
    ConterStyle: {
        marginTop:      5,
        marginButtom:   5,
    },
    CampStyle: {
        padding:  5,
        backgroundColor: 'skyblue',
        color: 'steelblue',
        textAlign:'center',
        borderStyle:'solid',
        borderWidth: 2,
    }
})